package com.example.simplecalculator;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(CalculatorApp.class, args);
    }
}
